
# Investigación sobre Estructuras de Datos en Java

Este documento contiene una investigación sobre las estructuras de datos más utilizadas en Java: `ArrayList`, `LinkedList`, `Queue`, `Stack` y `HashMap`. Incluye una breve explicación y un ejemplo funcional para cada una.

---

## 1. ArrayList

### 📄 Descripción:
- Lista dinámica que permite acceso rápido por índice.
- Mantiene el orden de inserción.
- Permite elementos duplicados.

### 💻 Código:
```java
import java.util.ArrayList;

public class EjemploArrayList {
    public static void main(String[] args) {
        ArrayList<String> frutas = new ArrayList<>();

        frutas.add("Manzana");
        frutas.add("Banana");
        frutas.remove("Banana");
        String primera = frutas.get(0);

        System.out.println("Primera fruta: " + primera);
    }
}
```

---

## 2. LinkedList

### 📄 Descripción:
- Lista doblemente enlazada.
- Más eficiente para inserciones/eliminaciones.
- Puede actuar como pila o cola.

### 💻 Código:
```java
import java.util.LinkedList;

public class EjemploLinkedList {
    public static void main(String[] args) {
        LinkedList<String> tareas = new LinkedList<>();

        tareas.add("Estudiar");
        tareas.add("Hacer ejercicio");
        tareas.removeFirst();
        String siguiente = tareas.peek();

        System.out.println("Siguiente tarea: " + siguiente);
    }
}
```

---

## 3. Queue (Cola)

### 📄 Descripción:
- Estructura FIFO (First-In, First-Out).
- Se usa para procesar elementos en orden.

### 💻 Código:
```java
import java.util.Queue;
import java.util.LinkedList;

public class EjemploQueue {
    public static void main(String[] args) {
        Queue<String> clientes = new LinkedList<>();

        clientes.add("Carlos");
        clientes.add("Lucía");
        String primero = clientes.peek();
        clientes.poll();

        System.out.println("Cliente atendido: " + primero);
    }
}
```

---

## 4. Stack (Pila)

### 📄 Descripción:
- Estructura LIFO (Last-In, First-Out).
- Se usa para deshacer acciones, navegación, etc.

### 💻 Código:
```java
import java.util.Stack;

public class EjemploStack {
    public static void main(String[] args) {
        Stack<String> paginas = new Stack<>();

        paginas.push("Inicio");
        paginas.push("Contacto");
        String ultima = paginas.peek();
        paginas.pop();

        System.out.println("Página actual: " + ultima);
    }
}
```

---

## 5. HashMap (Diccionario)

### 📄 Descripción:
- Almacena pares clave-valor.
- No permite claves duplicadas.
- Acceso rápido por clave.

### 💻 Código:
```java
import java.util.HashMap;

public class EjemploHashMap {
    public static void main(String[] args) {
        HashMap<String, Integer> edades = new HashMap<>();

        edades.put("Ana", 22);
        edades.put("Luis", 30);
        int edadAna = edades.get("Ana");
        edades.remove("Luis");

        System.out.println("Edad de Ana: " + edadAna);
    }
}
```

---

## ✅ Conclusión
Cada estructura tiene su uso según el contexto:
- `ArrayList`: acceso rápido por índice.
- `LinkedList`: inserciones frecuentes.
- `Queue`: procesamiento en orden.
- `Stack`: control de historial o deshacer.
- `HashMap`: acceso por clave.

> Este documento puede usarse como referencia y ejemplo en repositorios educativos sobre Java y estructuras de datos.
